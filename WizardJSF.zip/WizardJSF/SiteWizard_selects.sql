USE SiteWizard;

SELECT * FROM site;