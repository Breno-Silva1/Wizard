DROP DATABASE IF EXISTS SiteWizard;
CREATE DATABASE SiteWizard DEFAULT CHARACTER SET UTF8;

USE SiteWizard;

CREATE TABLE site (
	id INT AUTO_INCREMENT PRIMARY KEY,
	nomeDoSite VARCHAR(20) NOT NULL,
	sloganDoSite VARCHAR(50),
	sobreDescricao VARCHAR(5000) NOT NULL,
	contatoDescricao VARCHAR(100),
	rodapeLocalizacao VARCHAR(200),
    rodapeRedesSociaisF VARCHAR(100),
    rodapeRedesSociaisI VARCHAR(100),
    rodapeRedesSociaisY VARCHAR(100),
    rodapeRedesSociaisT VARCHAR(100),
    cep VARCHAR(15) NOT NULL,
    endereco VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    estado VARCHAR(50) NOT NULL,
    organizador1 VARCHAR(50),
    organizador2 VARCHAR(50),
    organizador3 VARCHAR(50),
    organizador4 VARCHAR(50),
    organizador5 VARCHAR(50),
    organizador6 VARCHAR(50),
    organizador7 VARCHAR(50),
    organizador8 VARCHAR(50),
    opcDeCor VARCHAR(20)

);